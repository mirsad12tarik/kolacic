package catalogue.contentful.lib;

public interface ItemClickListener<T> {
  void onItemClick(T object);
}